
from flaskblog  import  db

db.create_all()

class Vase(db.Model):
    __tablename__="vases"

    vase_id = db.Column(db.String, primary_key=True)
    vase_num = db.Column(db.Integer, nullable=False, default=" ")
    provence = db.Column(db.String, nullable=False, default=" ")
    year = db.Column(db.Integer, nullable=False, default=" ")
    shape_name = db.Column(db.String, nullable=False, default=" ")
    dimensions = db.Column(db.String, default=" ")
    description = db.Column(db.String, default=" ")
    author = db.Column(db.String, nullable=False, default="A. D. Trendall")
    publication = db.Column(db.String, nullable=False, default="The red Vases of paestum")
    images = db.relationship('Image_file', backref='vase', lazy=True, collection_class=list,
                                cascade="save-update, delete")
    """
    def disp(self):

        #Method to return representation of the Vase object

        formatted_images= [Image_file.disp() for Image_file in self.images]
        return {
            "vase_num": self.vase_num,
            "shape_name": self.shape_name,
            "provence": self.provence,
            "year": self.year,
            "dimensions": self.dimensions,
            "author": self.author,
            "publication": self.publication,
            "images": formatted_images,
            "description": self.description
        }
    """
    def __repr__(self):
        return f"Vase('vase_id={self.vase_id}', '{Image_file.image_file}', {self.vase_num}', {self.shape_name}, {self.provence}, {self.year}, {self.dimensions}, {self.author}, {self.publication}, {self.description})"

class Image_file(db.Model):
    __tablename__="images"

    id = db.Column(db.Integer, primary_key=True,)
    image_file = db.Column(db.String, nullable=False, default='default.jpg')
    vase_id = db.Column(db.String, db.ForeignKey('vases.vase_id'),nullable=False)
    """
    def disp(self):

        #Method to return representation of the Image_file object
        formatted_vases= [Vase.disp() for vases in self.vase_id]
        return{
            "image_file": self.image_file,
            "vase_id": formatted_vases
        }
    """
    def __repr__(self):
        return f"Image_file('{self.id}', {self.image_file}',{self.vase_id})"

