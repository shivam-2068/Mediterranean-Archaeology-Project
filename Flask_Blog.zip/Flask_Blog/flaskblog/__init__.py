
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship

app = Flask(__name__)

app.config['SECRET_KEY'] = '4d9db0ae882ba46315043ac5c20b5b41'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///archive.db'
#app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///list.db'

app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)
"""
def attach_db(app: Flask, database_path: str):

    #attach_db
    #   binds a database to a flask application using SQLAlchemy library

    app.config["SQLALCHEMY_DATABASE_URI"] = 'sqlite:///archive.db'
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    db.app = app
    db.init_app(app)
"""
from flaskblog import routes
